--
-- PostgreSQL database dump
--

\restrict 0ghtm8O7Rxo8bc5LmIRtGLP9apOfUa5l4Ih7KxsLCLnTi9njLCOophKGLrPfgam

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.idx_user_user_id;
DROP INDEX IF EXISTS public.idx_user_timestamp;
DROP INDEX IF EXISTS public.idx_user_service_name;
DROP INDEX IF EXISTS public.idx_user_entity_type;
DROP INDEX IF EXISTS public.idx_user_entity_id;
DROP INDEX IF EXISTS public.idx_user_action;
DROP INDEX IF EXISTS public.idx_transaction_user_id;
DROP INDEX IF EXISTS public.idx_transaction_timestamp;
DROP INDEX IF EXISTS public.idx_transaction_service_name;
DROP INDEX IF EXISTS public.idx_transaction_entity_type;
DROP INDEX IF EXISTS public.idx_transaction_entity_id;
DROP INDEX IF EXISTS public.idx_transaction_action;
DROP INDEX IF EXISTS public.idx_account_user_id;
DROP INDEX IF EXISTS public.idx_account_timestamp;
DROP INDEX IF EXISTS public.idx_account_service_name;
DROP INDEX IF EXISTS public.idx_account_entity_type;
DROP INDEX IF EXISTS public.idx_account_entity_id;
DROP INDEX IF EXISTS public.idx_account_action;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
ALTER TABLE IF EXISTS ONLY public.user_audit_logs DROP CONSTRAINT IF EXISTS user_audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.transaction_audit_logs DROP CONSTRAINT IF EXISTS transaction_audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
ALTER TABLE IF EXISTS ONLY public.account_audit_logs DROP CONSTRAINT IF EXISTS account_audit_logs_pkey;
DROP TABLE IF EXISTS public.user_audit_logs;
DROP TABLE IF EXISTS public.transaction_audit_logs;
DROP TABLE IF EXISTS public.flyway_schema_history;
DROP TABLE IF EXISTS public.account_audit_logs;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_audit_logs (
    id character varying(255) NOT NULL,
    service_name character varying(100) NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    user_id character varying(100),
    ip_address character varying(50),
    user_agent character varying(500),
    old_values text,
    new_values text,
    changes text,
    result character varying(50),
    error_message text,
    metadata text,
    "timestamp" timestamp without time zone NOT NULL,
    CONSTRAINT check_result CHECK (((result)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILURE'::character varying, 'PENDING'::character varying])::text[])))
);


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: transaction_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaction_audit_logs (
    id character varying(255) NOT NULL,
    service_name character varying(100) NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    user_id character varying(100),
    ip_address character varying(50),
    user_agent character varying(500),
    old_values text,
    new_values text,
    changes text,
    result character varying(50),
    error_message text,
    metadata text,
    "timestamp" timestamp without time zone NOT NULL,
    CONSTRAINT check_transaction_result CHECK (((result)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILURE'::character varying, 'PENDING'::character varying])::text[])))
);


--
-- Name: user_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_audit_logs (
    id character varying(255) NOT NULL,
    service_name character varying(100) NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    user_id character varying(100),
    ip_address character varying(50),
    user_agent character varying(500),
    old_values text,
    new_values text,
    changes text,
    result character varying(50),
    error_message text,
    metadata text,
    "timestamp" timestamp without time zone NOT NULL,
    CONSTRAINT check_user_result CHECK (((result)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILURE'::character varying, 'PENDING'::character varying])::text[])))
);


--
-- Data for Name: account_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_audit_logs (id, service_name, entity_type, entity_id, action, user_id, ip_address, user_agent, old_values, new_values, changes, result, error_message, metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	Initial Schema	SQL	V1__Initial_Schema.sql	-465978161	postgres	2026-01-04 14:39:43.621609	411	t
\.


--
-- Data for Name: transaction_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transaction_audit_logs (id, service_name, entity_type, entity_id, action, user_id, ip_address, user_agent, old_values, new_values, changes, result, error_message, metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: user_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_audit_logs (id, service_name, entity_type, entity_id, action, user_id, ip_address, user_agent, old_values, new_values, changes, result, error_message, metadata, "timestamp") FROM stdin;
\.


--
-- Name: account_audit_logs account_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_audit_logs
    ADD CONSTRAINT account_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: transaction_audit_logs transaction_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_audit_logs
    ADD CONSTRAINT transaction_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: user_audit_logs user_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_audit_logs
    ADD CONSTRAINT user_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_account_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_action ON public.account_audit_logs USING btree (action);


--
-- Name: idx_account_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_entity_id ON public.account_audit_logs USING btree (entity_id);


--
-- Name: idx_account_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_entity_type ON public.account_audit_logs USING btree (entity_type);


--
-- Name: idx_account_service_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_service_name ON public.account_audit_logs USING btree (service_name);


--
-- Name: idx_account_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_timestamp ON public.account_audit_logs USING btree ("timestamp");


--
-- Name: idx_account_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_user_id ON public.account_audit_logs USING btree (user_id);


--
-- Name: idx_transaction_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_action ON public.transaction_audit_logs USING btree (action);


--
-- Name: idx_transaction_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_entity_id ON public.transaction_audit_logs USING btree (entity_id);


--
-- Name: idx_transaction_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_entity_type ON public.transaction_audit_logs USING btree (entity_type);


--
-- Name: idx_transaction_service_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_service_name ON public.transaction_audit_logs USING btree (service_name);


--
-- Name: idx_transaction_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_timestamp ON public.transaction_audit_logs USING btree ("timestamp");


--
-- Name: idx_transaction_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transaction_user_id ON public.transaction_audit_logs USING btree (user_id);


--
-- Name: idx_user_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_action ON public.user_audit_logs USING btree (action);


--
-- Name: idx_user_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_entity_id ON public.user_audit_logs USING btree (entity_id);


--
-- Name: idx_user_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_entity_type ON public.user_audit_logs USING btree (entity_type);


--
-- Name: idx_user_service_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_service_name ON public.user_audit_logs USING btree (service_name);


--
-- Name: idx_user_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_timestamp ON public.user_audit_logs USING btree ("timestamp");


--
-- Name: idx_user_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_user_id ON public.user_audit_logs USING btree (user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 0ghtm8O7Rxo8bc5LmIRtGLP9apOfUa5l4Ih7KxsLCLnTi9njLCOophKGLrPfgam

