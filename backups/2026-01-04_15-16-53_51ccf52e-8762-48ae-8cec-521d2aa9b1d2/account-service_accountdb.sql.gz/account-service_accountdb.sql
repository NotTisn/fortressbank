--
-- PostgreSQL database dump
--

\restrict OcptBJEbSnbXVP23Q15hBeCr2CfWkmKro3wBLa4vsl9wvhp9iHuCSbd1xU70lwc

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.idx_status;
DROP INDEX IF EXISTS public.idx_outbox_status_created;
DROP INDEX IF EXISTS public.idx_outbox_aggregate;
DROP INDEX IF EXISTS public.idx_created_at;
DROP INDEX IF EXISTS public.idx_card_status;
DROP INDEX IF EXISTS public.idx_card_account;
DROP INDEX IF EXISTS public.idx_beneficiary_owner;
DROP INDEX IF EXISTS public.idx_audit_user;
DROP INDEX IF EXISTS public.idx_audit_timestamp;
DROP INDEX IF EXISTS public.idx_audit_status;
DROP INDEX IF EXISTS public.idx_audit_sender_account;
DROP INDEX IF EXISTS public.idx_audit_risk_level;
DROP INDEX IF EXISTS public.idx_audit_receiver_account;
DROP INDEX IF EXISTS public.idx_account_id;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
ALTER TABLE IF EXISTS ONLY public.transfer_audit_logs DROP CONSTRAINT IF EXISTS transfer_audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.transaction_idempotency DROP CONSTRAINT IF EXISTS transaction_idempotency_pkey;
ALTER TABLE IF EXISTS ONLY public.outbox_events DROP CONSTRAINT IF EXISTS outbox_events_pkey;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
ALTER TABLE IF EXISTS ONLY public.cards DROP CONSTRAINT IF EXISTS cards_pkey;
ALTER TABLE IF EXISTS ONLY public.cards DROP CONSTRAINT IF EXISTS cards_card_number_key;
ALTER TABLE IF EXISTS ONLY public.beneficiaries DROP CONSTRAINT IF EXISTS beneficiaries_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_account_number_key;
ALTER TABLE IF EXISTS public.beneficiaries ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.transfer_audit_logs;
DROP TABLE IF EXISTS public.transaction_idempotency;
DROP TABLE IF EXISTS public.outbox_events;
DROP TABLE IF EXISTS public.flyway_schema_history;
DROP TABLE IF EXISTS public.cards;
DROP SEQUENCE IF EXISTS public.beneficiaries_id_seq;
DROP TABLE IF EXISTS public.beneficiaries;
DROP TABLE IF EXISTS public.accounts;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    account_id character varying(255) NOT NULL,
    account_number character varying(20) NOT NULL,
    user_id character varying(255) NOT NULL,
    balance numeric(19,2) NOT NULL,
    pin_hash character varying(255),
    status character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: beneficiaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.beneficiaries (
    id bigint NOT NULL,
    owner_id character varying(255) NOT NULL,
    account_number character varying(255) NOT NULL,
    account_name character varying(255) NOT NULL,
    bank_name character varying(255),
    nick_name character varying(255)
);


--
-- Name: beneficiaries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.beneficiaries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: beneficiaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.beneficiaries_id_seq OWNED BY public.beneficiaries.id;


--
-- Name: cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cards (
    card_id character varying(255) NOT NULL,
    account_id character varying(255) NOT NULL,
    card_number character varying(16) NOT NULL,
    card_holder_name character varying(255) NOT NULL,
    cvv_hash character varying(255) NOT NULL,
    expiration_date date NOT NULL,
    card_type character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox_events (
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_type character varying(100) NOT NULL,
    aggregate_id character varying(100) NOT NULL,
    event_type character varying(100) NOT NULL,
    exchange character varying(255) NOT NULL,
    routing_key character varying(255) NOT NULL,
    payload text NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    retry_count integer DEFAULT 0,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed_at timestamp without time zone,
    CONSTRAINT outbox_events_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'PROCESSING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying])::text[])))
);


--
-- Name: transaction_idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaction_idempotency (
    transaction_id character varying(255) NOT NULL,
    account_id character varying(255) NOT NULL,
    operation_type character varying(20) NOT NULL,
    amount numeric(19,2) NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp without time zone
);


--
-- Name: TABLE transaction_idempotency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.transaction_idempotency IS 'Ensures idempotency for account balance operations - prevents duplicate processing of same transaction';


--
-- Name: transfer_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_audit_logs (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    sender_account_id character varying(255) NOT NULL,
    receiver_account_id character varying(255) NOT NULL,
    amount numeric(19,2) NOT NULL,
    status character varying(20) NOT NULL,
    risk_level character varying(20),
    challenge_type character varying(20),
    device_fingerprint character varying(255),
    ip_address character varying(45),
    location character varying(100),
    failure_reason character varying(500),
    "timestamp" timestamp without time zone NOT NULL
);


--
-- Name: beneficiaries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beneficiaries ALTER COLUMN id SET DEFAULT nextval('public.beneficiaries_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (account_id, account_number, user_id, balance, pin_hash, status, created_at) FROM stdin;
40e6a5c0-2a0b-4e1a-8b0a-0e0a0e0a0e0a	1000000001	a97acebd-b885-4dcd-9881-c9b2ef66e0ea	1000000.00	\N	ACTIVE	2026-01-04 14:41:04.635176
40e6a5c0-2a0b-4e1a-8b0a-0e0a0e0a0e0b	1000000002	user-jane-doe	12345.00	\N	ACTIVE	2026-01-04 14:41:04.635176
40e6a5c0-2a0b-4e1a-8b0a-0e0a0e0a0e0c	1000000003	user-john-smith	987.65	\N	ACTIVE	2026-01-04 14:41:04.635176
123e4567-e89b-12d3-a456-426614174000	1000000004	test-user-1	10000000.00	\N	ACTIVE	2026-01-04 14:41:04.635176
987fcdeb-51a2-43f7-89ab-123456789abc	1000000005	test-user-2	0.00	\N	ACTIVE	2026-01-04 14:41:04.635176
a1b2c3d4-e5f6-7890-1234-567890abcdef	1000000006	user-test-1	5000.00	\N	ACTIVE	2026-01-04 14:41:04.635176
fedcba98-7654-3210-fedc-ba9876543210	1000000007	user-test-2	2500.00	\N	ACTIVE	2026-01-04 14:41:04.635176
\.


--
-- Data for Name: beneficiaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.beneficiaries (id, owner_id, account_number, account_name, bank_name, nick_name) FROM stdin;
\.


--
-- Data for Name: cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cards (card_id, account_id, card_number, card_holder_name, cvv_hash, expiration_date, card_type, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	Initial schema	SQL	V1__Initial_schema.sql	1086612682	postgres	2026-01-04 14:41:03.910698	175	t
2	2	Add Idempotency Table	SQL	V2__Add_Idempotency_Table.sql	1137497621	postgres	2026-01-04 14:41:04.185708	70	t
3	3	Add Outbox Table	SQL	V3__Add_Outbox_Table.sql	1238024814	postgres	2026-01-04 14:41:04.305634	82	t
4	4	Add Beneficiary And Card Tables	SQL	V4__Add_Beneficiary_And_Card_Tables.sql	-1333180226	postgres	2026-01-04 14:41:04.438847	111	t
5	5	Remove Account Type	SQL	V5__Remove_Account_Type.sql	-1281590819	postgres	2026-01-04 14:41:04.588944	15	t
6	6	seed test data	SQL	V6__seed_test_data.sql	1314168580	postgres	2026-01-04 14:41:04.624043	13	t
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbox_events (event_id, aggregate_type, aggregate_id, event_type, exchange, routing_key, payload, status, retry_count, error_message, created_at, processed_at) FROM stdin;
\.


--
-- Data for Name: transaction_idempotency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transaction_idempotency (transaction_id, account_id, operation_type, amount, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: transfer_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_audit_logs (id, user_id, sender_account_id, receiver_account_id, amount, status, risk_level, challenge_type, device_fingerprint, ip_address, location, failure_reason, "timestamp") FROM stdin;
\.


--
-- Name: beneficiaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.beneficiaries_id_seq', 1, false);


--
-- Name: accounts accounts_account_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_account_number_key UNIQUE (account_number);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_id);


--
-- Name: beneficiaries beneficiaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beneficiaries
    ADD CONSTRAINT beneficiaries_pkey PRIMARY KEY (id);


--
-- Name: cards cards_card_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_card_number_key UNIQUE (card_number);


--
-- Name: cards cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_pkey PRIMARY KEY (card_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (event_id);


--
-- Name: transaction_idempotency transaction_idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_idempotency
    ADD CONSTRAINT transaction_idempotency_pkey PRIMARY KEY (transaction_id);


--
-- Name: transfer_audit_logs transfer_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_audit_logs
    ADD CONSTRAINT transfer_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_id ON public.transaction_idempotency USING btree (account_id);


--
-- Name: idx_audit_receiver_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_receiver_account ON public.transfer_audit_logs USING btree (receiver_account_id);


--
-- Name: idx_audit_risk_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_risk_level ON public.transfer_audit_logs USING btree (risk_level);


--
-- Name: idx_audit_sender_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_sender_account ON public.transfer_audit_logs USING btree (sender_account_id);


--
-- Name: idx_audit_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_status ON public.transfer_audit_logs USING btree (status);


--
-- Name: idx_audit_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_timestamp ON public.transfer_audit_logs USING btree ("timestamp");


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_user ON public.transfer_audit_logs USING btree (user_id);


--
-- Name: idx_beneficiary_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_beneficiary_owner ON public.beneficiaries USING btree (owner_id);


--
-- Name: idx_card_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_card_account ON public.cards USING btree (account_id);


--
-- Name: idx_card_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_card_status ON public.cards USING btree (status);


--
-- Name: idx_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_created_at ON public.transaction_idempotency USING btree (created_at);


--
-- Name: idx_outbox_aggregate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_outbox_aggregate ON public.outbox_events USING btree (aggregate_type, aggregate_id);


--
-- Name: idx_outbox_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_outbox_status_created ON public.outbox_events USING btree (status, created_at);


--
-- Name: idx_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_status ON public.transaction_idempotency USING btree (status);


--
-- PostgreSQL database dump complete
--

\unrestrict OcptBJEbSnbXVP23Q15hBeCr2CfWkmKro3wBLa4vsl9wvhp9iHuCSbd1xU70lwc

