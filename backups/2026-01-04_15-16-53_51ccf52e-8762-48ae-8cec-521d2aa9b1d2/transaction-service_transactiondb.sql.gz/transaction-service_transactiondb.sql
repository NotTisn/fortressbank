--
-- PostgreSQL database dump
--

\restrict MDJIJWPtRvj2ZeKGEGgBEt4boIYOwbCVnr0DH0CLIVqMW9eijVRQV4ya3tALQCK

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.transaction_otps DROP CONSTRAINT IF EXISTS fk_transaction_otp;
DROP INDEX IF EXISTS public.idx_webhook_received_at;
DROP INDEX IF EXISTS public.idx_stripe_transfer_id;
DROP INDEX IF EXISTS public.idx_status_date;
DROP INDEX IF EXISTS public.idx_status_created;
DROP INDEX IF EXISTS public.idx_sender_user_id;
DROP INDEX IF EXISTS public.idx_sender_date;
DROP INDEX IF EXISTS public.idx_sender_account_number;
DROP INDEX IF EXISTS public.idx_receiver_user_id;
DROP INDEX IF EXISTS public.idx_receiver_date;
DROP INDEX IF EXISTS public.idx_receiver_account_number;
DROP INDEX IF EXISTS public.idx_otp_transaction;
DROP INDEX IF EXISTS public.idx_otp_expires;
DROP INDEX IF EXISTS public.idx_idempotency_key;
DROP INDEX IF EXISTS public.idx_current_step;
DROP INDEX IF EXISTS public.idx_correlation_id;
DROP INDEX IF EXISTS public.idx_aggregate;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_idempotency_key_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_correlation_id_key;
ALTER TABLE IF EXISTS ONLY public.transaction_otps DROP CONSTRAINT IF EXISTS transaction_otps_pkey;
ALTER TABLE IF EXISTS ONLY public.transaction_limits DROP CONSTRAINT IF EXISTS transaction_limits_pkey;
ALTER TABLE IF EXISTS ONLY public.transaction_fees DROP CONSTRAINT IF EXISTS transaction_fees_transaction_type_key;
ALTER TABLE IF EXISTS ONLY public.transaction_fees DROP CONSTRAINT IF EXISTS transaction_fees_pkey;
ALTER TABLE IF EXISTS ONLY public.outbox_events DROP CONSTRAINT IF EXISTS outbox_events_pkey;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
ALTER TABLE IF EXISTS public.transaction_fees ALTER COLUMN fee_id DROP DEFAULT;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.transaction_otps;
DROP TABLE IF EXISTS public.transaction_limits;
DROP SEQUENCE IF EXISTS public.transaction_fees_fee_id_seq;
DROP TABLE IF EXISTS public.transaction_fees;
DROP TABLE IF EXISTS public.outbox_events;
DROP TABLE IF EXISTS public.flyway_schema_history;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox_events (
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_type character varying(100) NOT NULL,
    aggregate_id character varying(100) NOT NULL,
    event_type character varying(100) NOT NULL,
    exchange character varying(255) NOT NULL,
    routing_key character varying(255) NOT NULL,
    payload text NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    retry_count integer DEFAULT 0,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed_at timestamp without time zone,
    CONSTRAINT outbox_events_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'PROCESSING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying])::text[])))
);


--
-- Name: transaction_fees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaction_fees (
    fee_id bigint NOT NULL,
    transaction_type character varying(20) NOT NULL,
    fee_amount numeric(19,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT transaction_fees_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['INTERNAL_TRANSFER'::character varying, 'EXTERNAL_TRANSFER'::character varying, 'BILL_PAYMENT'::character varying, 'DEPOSIT'::character varying, 'WITHDRAWAL'::character varying])::text[])))
);


--
-- Name: transaction_fees_fee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transaction_fees_fee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transaction_fees_fee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transaction_fees_fee_id_seq OWNED BY public.transaction_fees.fee_id;


--
-- Name: transaction_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaction_limits (
    account_id character varying(255) NOT NULL,
    daily_limit numeric(19,2) DEFAULT 50000000.00 NOT NULL,
    daily_used numeric(19,2) DEFAULT 0.00 NOT NULL,
    last_daily_reset timestamp without time zone,
    monthly_limit numeric(19,2) DEFAULT 500000000.00 NOT NULL,
    monthly_used numeric(19,2) DEFAULT 0.00 NOT NULL,
    last_monthly_reset timestamp without time zone,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: transaction_otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaction_otps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    transaction_id uuid NOT NULL,
    otp_code character varying(6) NOT NULL,
    phone_number character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    verified_at timestamp without time zone,
    attempt_count integer DEFAULT 0 NOT NULL
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    transaction_id uuid DEFAULT gen_random_uuid() NOT NULL,
    sender_account_id character varying(255) NOT NULL,
    receiver_account_id character varying(255),
    amount numeric(19,2) NOT NULL,
    fee_amount numeric(19,2) DEFAULT 0.00,
    description text NOT NULL,
    transaction_type character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    transfer_type character varying(20),
    external_transaction_id character varying(255),
    destination_bank_code character varying(50),
    correlation_id character varying(255),
    current_step character varying(50),
    failure_step character varying(50),
    failure_reason text,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    stripe_transfer_id character varying(100),
    stripe_transfer_status character varying(50),
    stripe_failure_code character varying(100),
    stripe_failure_message text,
    webhook_received_at timestamp without time zone,
    idempotency_key character varying(100),
    sender_user_id character varying(255),
    receiver_user_id character varying(255),
    sender_account_number character varying(50),
    receiver_account_number character varying(50),
    CONSTRAINT transactions_current_step_check CHECK (((current_step IS NULL) OR ((current_step)::text = ANY ((ARRAY['STARTED'::character varying, 'OTP_VERIFIED'::character varying, 'DEBITED'::character varying, 'CREDITED'::character varying, 'COMPLETED'::character varying, 'ROLLING_BACK'::character varying, 'ROLLED_BACK'::character varying, 'FAILED'::character varying, 'ROLLBACK_FAILED'::character varying, 'EXTERNAL_INITIATED'::character varying])::text[])))),
    CONSTRAINT transactions_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING_OTP'::character varying, 'PENDING_FACE_AUTH'::character varying, 'PENDING'::character varying, 'PROCESSING'::character varying, 'COMPLETED'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELLED'::character varying, 'OTP_EXPIRED'::character varying, 'ROLLBACK_FAILED'::character varying, 'ROLLBACK_COMPLETED'::character varying])::text[]))),
    CONSTRAINT transactions_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['INTERNAL_TRANSFER'::character varying, 'EXTERNAL_TRANSFER'::character varying, 'BILL_PAYMENT'::character varying, 'DEPOSIT'::character varying, 'WITHDRAWAL'::character varying])::text[]))),
    CONSTRAINT transactions_transfer_type_check CHECK (((transfer_type IS NULL) OR ((transfer_type)::text = ANY ((ARRAY['INTERNAL'::character varying, 'EXTERNAL'::character varying])::text[]))))
);


--
-- Name: COLUMN transactions.stripe_transfer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.stripe_transfer_id IS 'Stripe transfer ID returned from Stripe API';


--
-- Name: COLUMN transactions.stripe_transfer_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.stripe_transfer_status IS 'Stripe transfer status: pending, in_transit, paid, failed, canceled';


--
-- Name: COLUMN transactions.stripe_failure_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.stripe_failure_code IS 'Stripe failure code if transfer failed';


--
-- Name: COLUMN transactions.stripe_failure_message; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.stripe_failure_message IS 'Stripe failure message if transfer failed';


--
-- Name: COLUMN transactions.webhook_received_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.webhook_received_at IS 'Timestamp when webhook was received from Stripe';


--
-- Name: COLUMN transactions.idempotency_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.idempotency_key IS 'Unique key for duplicate webhook prevention';


--
-- Name: transaction_fees fee_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_fees ALTER COLUMN fee_id SET DEFAULT nextval('public.transaction_fees_fee_id_seq'::regclass);


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	initial schema	SQL	V1__initial_schema.sql	105221190	postgres	2026-01-04 14:41:03.241009	531	t
2	2	Insert initial data	SQL	V2__Insert_initial_data.sql	1727845542	postgres	2026-01-04 14:41:03.881628	14	t
3	3	add stripe fields	SQL	V3__add_stripe_fields.sql	-146392460	postgres	2026-01-04 14:41:03.949393	92	t
4	4	add user account fields	SQL	V4__add_user_account_fields.sql	196705224	postgres	2026-01-04 14:41:04.073682	56	t
5	5	update transaction status constraint	SQL	V5__update_transaction_status_constraint.sql	1944957552	postgres	2026-01-04 14:41:04.15991	27	t
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbox_events (event_id, aggregate_type, aggregate_id, event_type, exchange, routing_key, payload, status, retry_count, error_message, created_at, processed_at) FROM stdin;
\.


--
-- Data for Name: transaction_fees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transaction_fees (fee_id, transaction_type, fee_amount, created_at, updated_at) FROM stdin;
1	INTERNAL_TRANSFER	0.00	2026-01-04 14:41:03.917774	2026-01-04 14:41:03.917774
2	EXTERNAL_TRANSFER	5000.00	2026-01-04 14:41:03.917774	2026-01-04 14:41:03.917774
3	BILL_PAYMENT	2000.00	2026-01-04 14:41:03.917774	2026-01-04 14:41:03.917774
4	DEPOSIT	0.00	2026-01-04 14:41:03.917774	2026-01-04 14:41:03.917774
5	WITHDRAWAL	3000.00	2026-01-04 14:41:03.917774	2026-01-04 14:41:03.917774
\.


--
-- Data for Name: transaction_limits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transaction_limits (account_id, daily_limit, daily_used, last_daily_reset, monthly_limit, monthly_used, last_monthly_reset, updated_at) FROM stdin;
\.


--
-- Data for Name: transaction_otps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transaction_otps (id, transaction_id, otp_code, phone_number, created_at, expires_at, verified, verified_at, attempt_count) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (transaction_id, sender_account_id, receiver_account_id, amount, fee_amount, description, transaction_type, status, transfer_type, external_transaction_id, destination_bank_code, correlation_id, current_step, failure_step, failure_reason, completed_at, created_at, updated_at, stripe_transfer_id, stripe_transfer_status, stripe_failure_code, stripe_failure_message, webhook_received_at, idempotency_key, sender_user_id, receiver_user_id, sender_account_number, receiver_account_number) FROM stdin;
\.


--
-- Name: transaction_fees_fee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transaction_fees_fee_id_seq', 5, true);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (event_id);


--
-- Name: transaction_fees transaction_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_fees
    ADD CONSTRAINT transaction_fees_pkey PRIMARY KEY (fee_id);


--
-- Name: transaction_fees transaction_fees_transaction_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_fees
    ADD CONSTRAINT transaction_fees_transaction_type_key UNIQUE (transaction_type);


--
-- Name: transaction_limits transaction_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_limits
    ADD CONSTRAINT transaction_limits_pkey PRIMARY KEY (account_id);


--
-- Name: transaction_otps transaction_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_otps
    ADD CONSTRAINT transaction_otps_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_correlation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_correlation_id_key UNIQUE (correlation_id);


--
-- Name: transactions transactions_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_aggregate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aggregate ON public.outbox_events USING btree (aggregate_type, aggregate_id);


--
-- Name: idx_correlation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_correlation_id ON public.transactions USING btree (correlation_id);


--
-- Name: idx_current_step; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_current_step ON public.transactions USING btree (current_step);


--
-- Name: idx_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_idempotency_key ON public.transactions USING btree (idempotency_key);


--
-- Name: idx_otp_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otp_expires ON public.transaction_otps USING btree (expires_at);


--
-- Name: idx_otp_transaction; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_otp_transaction ON public.transaction_otps USING btree (transaction_id);


--
-- Name: idx_receiver_account_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_receiver_account_number ON public.transactions USING btree (receiver_account_number);


--
-- Name: idx_receiver_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_receiver_date ON public.transactions USING btree (receiver_account_id, created_at);


--
-- Name: idx_receiver_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_receiver_user_id ON public.transactions USING btree (receiver_user_id);


--
-- Name: idx_sender_account_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sender_account_number ON public.transactions USING btree (sender_account_number);


--
-- Name: idx_sender_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sender_date ON public.transactions USING btree (sender_account_id, created_at);


--
-- Name: idx_sender_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sender_user_id ON public.transactions USING btree (sender_user_id);


--
-- Name: idx_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_status_created ON public.outbox_events USING btree (status, created_at);


--
-- Name: idx_status_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_status_date ON public.transactions USING btree (status, created_at);


--
-- Name: idx_stripe_transfer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stripe_transfer_id ON public.transactions USING btree (stripe_transfer_id);


--
-- Name: idx_webhook_received_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webhook_received_at ON public.transactions USING btree (webhook_received_at);


--
-- Name: transaction_otps fk_transaction_otp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_otps
    ADD CONSTRAINT fk_transaction_otp FOREIGN KEY (transaction_id) REFERENCES public.transactions(transaction_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict MDJIJWPtRvj2ZeKGEGgBEt4boIYOwbCVnr0DH0CLIVqMW9eijVRQV4ya3tALQCK

